# BELAGE Mobile "Game Entry" UI mini-kit

## What this is
A tiny asset+CSS pack to implement the style:
- dark sci-fi background
- subtle pixel grid + scanlines + noise overlays
- pixel cards / badges / divider / buttons
Mobile-first.

## How to use (in your repo)
1) Copy `assets/pixel/*` into your project at `/assets/pixel/`
2) Copy `styles/tokens.css` and `styles/pixel-layer.css` into `/styles/`
3) In your homepage `<head>` add:
   <link rel="stylesheet" href="styles/tokens.css">
   <link rel="stylesheet" href="styles/pixel-layer.css">

4) Apply classes in `home.js`:
- Wrap content in `.container`
- Use `.hero`, `.hero__title`, `.hero__subtitle`
- Use `.btn btn--primary` / `.btn btn--secondary`
- Use `.px-card`, `.px-card__title`, `.px-card__text`
- Use `.px-divider` between blocks

## Notes
- Overlays sit behind content (`body::before`), pointer-events disabled.
- No video. No heavy JS.
